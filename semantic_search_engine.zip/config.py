import os
DATABASE_PATH = os.path.join(os.path.join(os.getcwd(), 'db'), 'db.sqlite')