# Semantic Search Engine

Setup

1. Create Virtual Enviorment
        
        python3.6 -m venv venv
        

2. Activate Virtual Enviorment
        
        sourve venv/bin/activate
        
3. Install python dependencies

        pip install -r requirements.txt

